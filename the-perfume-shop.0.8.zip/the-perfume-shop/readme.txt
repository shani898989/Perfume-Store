=== The Perfume Shop ===
Contributors: TheMagnifico52
Requires at least: 5.5
Tested up to: 7.1
Requires PHP: 7.2
Stable tag: 0.8
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Tags: three-columns, four-columns, wide-blocks, block-styles, custom-logo, one-column, two-columns, grid-layout, sticky-post, custom-background, custom-colors, custom-header, custom-menu, featured-images, flexible-header, threaded-comments, theme-options, left-sidebar, right-sidebar, full-width-template, editor-style, e-commerce, portfolio, blog, post-formats, translation-ready

== Description ==

The Perfume Shop Theme is a sophisticated and adaptable solution tailored for fragrance businesses, beauty brands, and perfume retailers aiming to establish an elegant online presence. With its clean and minimalist design, the theme effectively showcases a diverse array of perfumes while ensuring a smooth browsing experience for customers. Its fully responsive, retina-ready layout guarantees high-quality visuals and usability across all devices, from desktops to smartphones. The theme also offers powerful customization options, enabling businesses to modify layouts, colors, typography, and branding to align with their unique identity. Optimized code and fast loading times enhance site efficiency and user experience. Additionally, features like testimonial sections, promotional banners, team showcases, and strategically placed Call to Action (CTA) buttons help boost engagement and conversions. The SEO-friendly structure combined with social media integration increases visibility, helping fragrance products reach a broader audience online. Built on a modern framework and enhanced with shortcode support, this theme seamlessly blends functionality with elegance, making it an excellent choice for businesses in the fragrance, beauty, and luxury retail sectors who seek a stylish and professional online platform.


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in The Perfume Shop in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

The Perfume Shop WordPress Theme, Copyright 2024 TheMagnifico52
The Perfume Shop is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

The Perfume Shop includes support for Infinite Scroll in Jetpack.

== Credits ==

The Perfume Shop bundles the following third-party resources:

Bootstrap, Copyright (c) 2011-2019 Twitter, Inc.
**License:** MIT
Source: https://github.com/twbs/bootstrap

Font Awesome Free 5.6.3 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

TGMPA
* GaryJones Copyright (C) 1989, 1991
* https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md
* License: GNU General Public License v2.0

OwlCarousel
 * Copyright 2013-2017 David Deutsch
 * https://github.com/OwlCarousel2/OwlCarousel2
 * https://github.com/OwlCarousel2/OwlCarousel2/blob/develop/LICENSE

Bootstrap
 * Bootstrap v4.3.1 (https://getbootstrap.com/)
 * Copyright 2011-2019 The Bootstrap Authors
 * Copyright 2011-2019 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

PSR-4 autoloader
  * Justin Tadlock
  * License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  * Source: https://github.com/WPTRT/autoload

Webfonts Loader
  * https://github.com/WPTT/webfont-loader
  * License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE

CustomizeSectionButton
  * Justin Tadlock
  * Copyright 2019, Justin Tadlock.
  * License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  * https://github.com/WPTRT/customize-section-button

Pxhere Images,
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/license

	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/127945

  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://pxhere.com/en/photo/1024012

  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://pxhere.com/en/photo/943806

  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://pxhere.com/en/photo/1212813

  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://pxhere.com/en/photo/418755

== Changelog ==

= 0.0.1

* Initial release.

= 0.0.2

* Menu hover color changed also in mobile media.

= 0.0.3

* Added footer credit link.
* Added copyright content alignment option in customizer.
* Added show / hide post page content option in customizer.  
* Added footer content alignment option in customizer.
* Added show / hide single post page content option in customizer.

= 0.0.4

* Added global color option in customizer.
* Added site width layout option in customizer.
* Added nav menus text transform option in customizer.

= 0.0.5

* Added POT files.

= 0.0.6

* Added product per page setting.
* Added show/hide single product page sidebar option in customizer.
* Added single product page sidebar layout option in customizer.
* Added show/hide shop page sidebar option in customizer.
* Added shop page sidebar layout option in customizer.

= 0.0.7

* Added scroll to top background color option in customizer.
* Added scroll to top color option in customizer.
* Added scroll to top font size option in customizer.
* Added scroll to top border radius option in customizer.
* Updated POT file.

= 0.0.8

* Added blog page excerpt length option in customizer.
* Added blog page excerpt suffix option in customizer.
* Added show / hide blog page navigation in customizer.
* Updated POT file.

= 0.0.9

* Added menu font size option in customizer.
* Added menu font weight option in customizer.
* Added menu text transform option in customizer.
* Updated POT file.

= 0.1.0

* Added preloader type option in customizer.
* Added preloader color option in customizer.
* Updated POT file.

= 0.1.1

* Added blog page pagination type option in customizer.
* Added number of posts per row option in customizer.
* Added blog page sidebar position option in customizer.
* Added single post sidebar position option in customizer.
* Added show/hide single post tag option in customizer.
* Updated POT file.

= 0.1.2

* Added footer background color option in customizer.
* Added footer content color option in customizer.
* Added copyright text color option in customizer.
* Added single page sidebar layout option in customizer.
* Updated POT file.

= 0.1.3

* Added menu css.
* Updated sidebar css.
* Added default sidebar.
* Added default css.
* Resolved textdomain error.

= 0.1.4

* Added upsales links in all section.

= 0.1.5

* Added woocommerce related product column setting.
* Added woocommerce related product per page setting.
* Added woocommerce related product show setting.

= 0.1.6

* Minor fixes and improvements.

= 0.1.7

* Update 404 page.
* Added 404 page setting.

= 0.1.8

* Added bundle notice.

= 0.1.9

* Added demo impoter.
* Updated getstart.

= 0.2.0

* Made some changes.

= 0.2.1

* Changed menu code.

= 0.2.2

* Update single.php file
* Update page single file.
* Update archive product file.
* Update single-product file.
* Update notice code.
* Added new code of global color.
* Updated Demo importer code.
* Update pattern file.
* Added some tags.
* Added post layout option.
* Updated getstart.

= 0.2.3

* Made some changes.

= 0.2.4

* Added pro btn in post layout settings.
* Added pro btn in 404 page settings.
* Added pro btn in product settings.
* Added 404 page settings.
* Added paragraph typography settings.
* Added heading yypography settings.
* Added sticky header.
* Added woocommerce product sale positions settings.
* Added woocommerce Product sale border radius settings.
* Added woocommerce product image box shadow settings.
* Added woocommerce Product image border radius settings.
* Added post page image border radius setting.
* Added post page image box shadow setting.
* Added single post page image border radius
* Added single post page image box shadow setting.
* Added Enable single post meta setting.
* Added Enable single post title setting.
* Added Enable single post tags setting.
* Added single post comment title setting.
* Added single post comment button text setting.

= 0.2.5 =
* Fixed: Added href attribute to back-to-top anchor element in footer.php.
* Fixed: Resolved orphaned div element in index.php template loop.
* Fixed: Corrected esc_url/esc_attr misuse in inc/template-tags.php comment author and date output; now uses get_comment_author_link() and esc_html__().
* Fixed: Removed stray </i> closing tag in template-parts/content-single.php.
* Fixed: Removed console.log in assets/js/theme-importer.js error handler.
* Fixed: Removed console.log calls from inc/theme-installation/assets/js/theme-installation.js error handlers.
* Fixed: Added _ajax_nonce field to recommend action AJAX request in theme-installation.js.
* Fixed: Renamed nr_actions_recommended to count_actions_recommended in wp_localize_script call.
* Fixed: Added recommend_action_nonce to wp_localize_script for theme-installation.
* Fixed: Added sanitize_key/wp_unslash to $_GET['id'] and $_GET['todo'] in theme-installation.php.
* Fixed: Added check_ajax_referer and current_user_can capability check to update_recommended_action_callback.
* Fixed: Escaped wp_get_theme() output with esc_html() in admin notice.
* Fixed: Corrected broken </h2> and </p> closing tags in admin notice HTML.
* Fixed: Replaced _e() with esc_html_e() for admin notice text.
* Fixed: Added check_ajax_referer to dismissable_notice AJAX handler.
* Fixed: Replaced die() with wp_die() in dismissable_notice handler.
* Fixed: Added add_action hook for ajax_notice_handler.
* Fixed: Added check_ajax_referer and current_user_can to tm_install_and_activate_plugin.
* Fixed: Added check_ajax_referer and current_user_can to tm_check_plugin_exists; sanitized $_POST values.
* Fixed: Replaced deprecated get_page_by_title() with get_posts() equivalent.

= 0.2.6 =
* Description Update.

= 0.2.7 =
* Version Updated.

= 0.2.8 =
* Added coupon code in getarted.
* Updated pot file.

= 0.3 
* Resolved css error in getstarted, notice and customizer.
* Added link to the bundle image.
* Added content.
* Tested Upto 7.0

= 0.4 =
* Minor Improvements and Fixes.
* Changed Theme URI.

= 0.5 =
* Responsive Design Improvements.

= 0.6 =
* Stability and Performance Enhancements.

= 0.7 =
* Enhanced Theme Compatibility.

= 0.8 =
* Fixed Styling Issues.
