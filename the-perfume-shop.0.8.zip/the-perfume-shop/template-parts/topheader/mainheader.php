<?php
/**
 * Displays main header
 *
 * @package The Perfume Shop
 */
?>

<div class="main-header text-center py-2">
    <div class="container">
        <div class="row nav-box">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 align-self-center header-box">
                <?php get_template_part('template-parts/navigation/nav'); ?>
            </div>
        </div>
    </div>
</div>
