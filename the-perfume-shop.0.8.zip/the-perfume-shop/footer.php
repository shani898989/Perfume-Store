<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package The Perfume Shop
 */
do_action('the_perfume_shop_before_footer_content_action');
?>

<footer id="colophon" class="site-footer border-top">
		    <div class="container">
		    	<div class="footer-column">
		    		<div class="row">
				        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
				          	<?php if (is_active_sidebar('the-perfume-shop-footer1')) : ?>
		                        <?php dynamic_sidebar('the-perfume-shop-footer1'); ?>
		                    <?php else : ?>
		                        <aside id="search" class="widget" role="complementary" aria-label="firstsidebar">
		                            <h5 class="widget-title"><?php esc_html_e( 'About Us', 'the-perfume-shop' ); ?></h5>
		                            <div class="textwidget">
		                            	<p><?php esc_html_e( 'Nam malesuada nulla nisi, ut faucibus magna congue nec. Ut libero tortor, tempus at auctor in, molestie at nisi. In enim ligula, consequat eu feugiat a.', 'the-perfume-shop' ); ?></p>
		                            </div>
		                        </aside>
		                    <?php endif; ?>
				        </div>
				        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
				            <?php if (is_active_sidebar('the-perfume-shop-footer2')) : ?>
		                        <?php dynamic_sidebar('the-perfume-shop-footer2'); ?>
		                    <?php else : ?>
		                        <aside id="pages" class="widget">
		                            <h5 class="widget-title"><?php esc_html_e( 'Useful Links', 'the-perfume-shop' ); ?></h5>
		                            <ul class="mt-4">
		                            	<li><?php esc_html_e( 'Home', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'services', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'Reviews', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'About Us', 'the-perfume-shop' ); ?></li>
		                            </ul>
		                        </aside>
		                    <?php endif; ?>
				        </div>
				        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
				            <?php if (is_active_sidebar('the-perfume-shop-footer3')) : ?>
		                        <?php dynamic_sidebar('the-perfume-shop-footer3'); ?>
		                    <?php else : ?>
		                        <aside id="pages" class="widget">
		                            <h5 class="widget-title"><?php esc_html_e( 'Information', 'the-perfume-shop' ); ?></h5>
		                            <ul class="mt-4">
		                            	<li><?php esc_html_e( 'FAQ', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'Site Maps', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'Privacy Policy', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'Contact Us', 'the-perfume-shop' ); ?></li>
		                            </ul>
		                        </aside>
		                    <?php endif; ?>
				        </div>
				        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
				            <?php if (is_active_sidebar('the-perfume-shop-footer4')) : ?>
		                        <?php dynamic_sidebar('the-perfume-shop-footer4'); ?>
		                    <?php else : ?>
		                        <aside id="pages" class="widget">
		                            <h5 class="widget-title"><?php esc_html_e( 'Get In Touch', 'the-perfume-shop' ); ?></h5>
		                            <ul class="mt-4">
		                            	<li><?php esc_html_e( 'Via Carlo Montù 78', 'the-perfume-shop' ); ?><br><?php esc_html_e( '22021 Bellagio CO, Italy', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( '+11 6254 7855', 'the-perfume-shop' ); ?></li>
		                            	<li><?php esc_html_e( 'support@example.com', 'the-perfume-shop' ); ?></li>
		                            </ul>
		                        </aside>
		                    <?php endif; ?>
				        </div>
			      	</div>
				</div>
		    	<?php if (get_theme_mod('the_perfume_shop_show_hide_copyright', true)) {?>
				        <div class="site-info text-center">
				            <div class="footer-menu-left">
				            	<?php  if( ! get_theme_mod('the_perfume_shop_footer_text_setting') ){ ?>
								    <a target="_blank" href="<?php echo esc_url('https://wordpress.org/', 'the-perfume-shop' ); ?>">
										<?php
										/* translators: %s: CMS name, i.e. wordpress. */
										printf( esc_html__( 'Proudly powered by %s', 'the-perfume-shop' ), 'WordPress' );
										?>
								    </a>
								    <span class="sep mr-1"> | </span>

								    <span>
								    	<a target="_blank" href="<?php echo esc_url( 'https://www.themagnifico.net/products/free-perfume-wordpress-theme'); ?>">
							              	<?php
							                /* translators: 1: Theme name,  */
							                printf( esc_html__( ' %1$s ', 'the-perfume-shop' ),'Perfume WordPress Theme' );
							              	?>
						              	</a>
							          	<?php
							              /* translators: 1: Theme author. */
							              printf( esc_html__( 'by %1$s.', 'the-perfume-shop' ),'TheMagnifico'  );
							            ?>
				        			</span>
								<?php }?>
								<?php echo esc_html(get_theme_mod('the_perfume_shop_footer_text_setting')); ?>
				            </div>
				        </div>
				<?php } ?>
			    <?php if (get_theme_mod('the_perfume_shop_scroll_hide', true)) {?>
			    	<a href="#" id="button"><?php esc_html_e('TOP','the-perfume-shop'); ?></a>
			    <?php } ?>
		    </div>
		</footer>
</div>

<?php wp_footer(); ?>

</body>
</html>